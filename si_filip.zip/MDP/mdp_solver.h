#include <vector>
#include <utility>
#include <unordered_map>

#include "mdp_instance.h"

class MDPSolver {
public:
	MDPSolver(MDPInstance & mdp_instance, float Epsilon, float Discount_factor ) : 
		mdp_instance{mdp_instance},
		Epsilon{Epsilon},
		Discount_factor{Discount_factor}
	{

	}

	void ValueIteration() {
		for (State state : mdp_instance) 
			Vprevious[state] = 0;
		while (!areAllStatesWithinThreshold()) {
			Vprevious = std::move(Vcurrent);
			for (State state : mdp_instance)
				computeStateValues(state);
		}
		//return {Pi, Vcurrent};
	}

private:
	bool areAllStatesWithinThreshold() {
		for (State state : mdp_instance) {
			if (abs(Vcurrent[state] - Vprevious[state]) < Epsilon)
				return false;
		}
		return true;
	}

	void computeStateValues(State & state) {
		float best_value{std::numeric_limits<float>::min()};
		Action best_action;
		for (Action & action : getPossibleActions()) {
			float state_reward = mdp_instance.calculateReward(state, action);
			float next_move_reward = calculateNextMovementValue(state, action);

			float reward = state_reward + next_move_reward;
			if (reward > best_value) {
				best_value = reward;
				best_action = action;
			}
		}
		Pi[state] = best_action;
		Vcurrent[state] = best_value;
	}

	float calculateNextMovementValue(State & state, Action action) {
		float value {0};
		for (State & target_state : mdp_instance.getNeighbouringStates(state))
			value += mdp_instance.calculateTransitionProbability(state, target_state, action) * Vprevious[target_state];
		return Discount_factor * value;
	}

	std::vector<Action> getPossibleActions() {
		static std::vector<Action> actions{Action::Up, Action::Down, Action::Left, Action::Right};
		return actions;
	}

	std::unordered_map<State, float, State::Hash> Vcurrent;
	std::unordered_map<State, float, State::Hash> Vprevious;
	std::unordered_map<State, Action, State::Hash> Pi;
	
	float Epsilon;
	float Discount_factor;
	MDPInstance & mdp_instance;
};
