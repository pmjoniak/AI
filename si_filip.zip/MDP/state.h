#include <utility>

struct State {
	State(std::pair<int,int> position) : x_position{position.first}, y_position{position.second} {}
	State() {}

	int x_position;
	int y_position;
	float reward;
	float action_reward;

	struct Hash {
		size_t operator() (const State & state) const {
			return state.y_position * 100 + state.x_position;
		} 
	};	
};


bool operator == (const State & s1, const State & s2) {
	return s1.x_position == s2.x_position && s1.y_position == s2.y_position;
}