#include <vector>
#include <unordered_set>
#include "state.h"

enum class Action {
	Up,
	Down,
	Left,
	Right
};

class MDPInstance {
public:
	MDPInstance(int width, int height, float move_probability)  : 
		world_width{width},
		world_height{height},
		proper_move_probability{move_probability},
		side_move_probability{(1.0f-move_probability)/2}
	{}

	const int world_width;
	const int world_height;

	const float proper_move_probability;
	const float side_move_probability;

	void addState(State state) {
		states.insert(state);
	}

	std::vector<State> getNeighbouringStates(State state) {
		std::vector<State> possible_actions;
		for (auto pos : { std::make_pair(-1, 0), std::make_pair(1, 0), std::make_pair(0, 1), std::make_pair(0, -1)}) {
			State desired_state = state;
			desired_state.x_position += pos.first;
			desired_state.y_position += pos.second;
			auto found_state = states.find(desired_state);
			if (found_state != states.end())
				possible_actions.push_back(*found_state);
		}
		return possible_actions;
	}

	float calculateReward(State & state, Action action) {
		float reward {};
		for (State & possible_state : getNeighbouringStates(state))
			reward += calculateTransitionProbability(state, possible_state, action) * possible_state.reward;
		return reward;
	}


	float calculateTransitionProbability(State & start_state, State & end_state, Action action) {
		int xdiff {end_state.x_position - start_state.x_position};
		int ydiff {end_state.y_position - start_state.y_position};

		int action_xdiff {action == Action::Left? -1 : (action == Action::Right? 1:0)};
		int action_ydiff {action == Action::Up ? 1 : (action == Action::Down?-1:0)};

		if (xdiff == action_xdiff && ydiff == action_ydiff)
			return proper_move_probability;
		if (xdiff == action_xdiff || ydiff == action_ydiff)
			return side_move_probability;
		return {};
	}

	std::unordered_set<State>::iterator begin() const {
		return states.begin();
	}

	std::unordered_set<State>::iterator end() const {
		return states.end();
	}
private:
	std::unordered_set<State> states;
};
