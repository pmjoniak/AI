package checkers; // Ten pakiet jest wymagany - nie usuwaj go
import java.util.Hashtable;

public class EvaluatePosition // Ta klasa jest wymagana - nie usuwaj jej
{
	static private final int WIN=Integer.MAX_VALUE/2;
	static private final int LOSE=Integer.MIN_VALUE/2;
	static private boolean _color; // To pole jest wymagane - nie usuwaj go

	static private Hashtable<String, Integer> numbers = new Hashtable<String, Integer>();
	static private Boolean precalculated = false;
	static private void v(String conf, int val)
	{/*
		for (int i=0; i<5; i++)
		{
			if (conf[i]=='?')
			{
				for (int k=1; k<6; k++) {
					conf[i] = Integer.toString(k)[0];
					v(conf, val);
				}
				return;
			}
		}*/
		numbers.put(conf, val);
	}

	static private char getVal(AIBoard board, int x, int y)
	{
		if (board._board[x][y].empty)
			return '3';
		if (board._board[i][j].white)
		{
			
		}
		
	}

	static private int evalSquare(AIBoard board, int x, int y)
	{
		String s = new String();
		s = s.concat()
	}

	static private void precalc()
	{
		v("12345", 0);



	}

	static public void changeColor(boolean color) // Ta metoda jest wymagana - nie zmieniaj jej
	{
		_color=color;
	}
	static public boolean getColor() // Ta metoda jest wymagana - nie zmieniaj jej
	{
		return _color;
	}
	static public int evaluatePosition(AIBoard board) // Ta metoda jest wymagana. Jest to główna metoda heurystyki - umieść swój kod tutaj
	{
		if (!precalculated) {
			precalc();
			precalculated = true;
		}

		int myRating=0;
		int opponentsRating=0;
		int size=board.getSize();

		for (int i=0;i<size;i++)
		{
			for (int j=(i+1)%2;j<size;j+=2)
			{
				if (!board._board[i][j].empty) // pole nie jest puste
				{
					if (board._board[i][j].white==getColor()) // to jest moj pionek
					{
						if (board._board[i][j].king) myRating+=3; // to jest moja damka
						else myRating+=1; // to jest moj pionek
					}
					else
					{
						if (board._board[i][j].king) opponentsRating+=3; // to jest damka przeciwnika
						else opponentsRating+=1;
					}
				}
			}
		}
		//Judge.updateLog("Tutaj wpisz swoją wiadomość - zobaczysz ją w oknie log\n");
		if (myRating==0) return LOSE; // przegrana
		else if (opponentsRating==0) return WIN; // wygrana
		else return myRating-opponentsRating;
	}
}
