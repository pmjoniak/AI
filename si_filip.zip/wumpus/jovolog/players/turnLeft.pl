act(Action, Knowledge) :-
	Action = turnLeft,
	Knowledge = [].