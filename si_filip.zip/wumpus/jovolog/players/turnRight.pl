act(Action, Knowledge) :-
	Action = turnRight,
	Knowledge = [].