act(Action, Knowledge) :-
	Action = exit,
	Knowledge = [].