act(Action, Knowledge) :-
	Action = shoot,
	Knowledge = [].