act(Action, Knowledge) :-
	Action = grab,
	Knowledge = [].