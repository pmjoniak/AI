act(Action, Knowledge) :-
	Action = moveForward,
	Knowledge = [].