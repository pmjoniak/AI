#!/bin/bash

java -jar Jovolog.jar
