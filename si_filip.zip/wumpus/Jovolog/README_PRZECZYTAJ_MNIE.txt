================================================================================
Uruchamianie: 
java -jar Jovolog.jar

================================================================================
Wi�cej informacji:
http://sequoia.ict.pwr.wroc.pl/~witold/aiuwr/2010_projekty/jovolog/

